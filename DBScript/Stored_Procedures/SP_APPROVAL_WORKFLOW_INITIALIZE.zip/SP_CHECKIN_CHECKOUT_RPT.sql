DELIMITER //

DROP PROCEDURE IF EXISTS SP_CHECKIN_CHECKOUT_RPT;
CREATE PROCEDURE SP_CHECKIN_CHECKOUT_RPT (
    IN Type VARCHAR(255),
    IN FromDate DATE,
    IN ToDate DATE,
    IN PlantId VARCHAR(255),
    IN VisitorTypeId VARCHAR(255),
    IN PurposeOfVisit VARCHAR(255)
)
BEGIN
    IF Type = 'CreateInitialize' THEN
        SELECT 
            Meta_Sub_Id AS MetaSubId,
            Meta_Type_Code AS MetaTypeCode,
            Meta_Sub_Code AS MetaSubCode,
            Meta_Type_Name AS MetaTypeName,
            Meta_Sub_Description AS MetaSubDescription,
            Status AS Status,
            Meta_Sub_Description AS StatusName,
            Created_By AS CreatedBy,
            Modified_By AS ModifiedBy,
            Modified_On AS ModifiedOn
        FROM Metadata 
        WHERE Meta_Type_Code = 'VIY' AND Status = 1;
        
        SELECT * FROM Metadata WHERE Meta_Type_Code = 'POV' AND Status = 1;
        
        SELECT * FROM Plant WHERE Status = 1;
        
        IF VisitorTypeId > 0 THEN
            SELECT * FROM Visitor_Entry WHERE Visitor_Type_Id = VisitorTypeId;
        END IF;
    END IF;
    
   IF Type = 'SearchInitialize' THEN
		-- Drop the temporary table if it already exists
DROP TEMPORARY TABLE IF EXISTS TempSelect;

-- Create the temporary table with the corrected datetime format
CREATE TEMPORARY TABLE TempSelect AS
SELECT *
FROM (
    SELECT DISTINCT
        v.Plant_Id AS PlantId,
        v.Visitor_Type_Id AS VisitorTypeId,
        'One Day Pass' AS VisitorTypeName,
        CONCAT(m.Meta_Sub_Description, '.', vd.First_Name, ' ', vd.Last_Name) AS VisitorName,
        v.Mobile_No AS MobileNo,
        v.Visited_Employee_Id AS VisitedEmployeeId,
        u2.User_Name AS VisitorEmpName,
        v.Purpose_Of_Visit AS PurposeOfVisit,
        m4.Meta_Sub_Description AS PurposeOfVisitName,
        v.Visitor_Image_Url AS VisitorImageUrl,
        v.Visitor_Entry_Code AS VisitorEntryCode,
        p.Plant_Name AS PlantName,
        IFNULL(DATE_FORMAT(v.Visitor_Entry_Date, '%Y-%m-%d %H:%i:%s'), '') AS VisitorEntryDate,
        IFNULL(DATE_FORMAT(vl.Checked_In, '%Y-%m-%d %H:%i:%s'), '') AS CheckedIn,
        IFNULL(DATE_FORMAT(vl.Checked_out, '%Y-%m-%d %H:%i:%s'), '') AS CheckedOut,
        CASE WHEN vl.Checked_out IS NULL THEN ''
             ELSE CONCAT(TIMESTAMPDIFF(MINUTE, vl.Checked_In, vl.Checked_Out), ' Minutes')
        END AS StayTime,
        u.User_Name AS CheckedInBy,
        IFNULL(u1.User_Name, '') AS CheckedOutBy,
        (SELECT GROUP_CONCAT(DISTINCT m.Area_Name SEPARATOR ', ') 
         FROM Visitor_Entry_Atv_Detail b 
         INNER JOIN Area m ON m.Area_Id = b.Area_To_Visit 
         WHERE b.Visitor_Entry_Id = v.Visitor_Entry_Id) AS AreatoVisitName
    FROM 
        Visitor_Entry_Detail vd
        INNER JOIN Visitor_Entry v ON v.Visitor_Entry_Id = vd.Visitor_Entry_Id AND v.Visitor_Type_Id = 35
        INNER JOIN Plant p ON p.Plant_Id = v.Plant_Id
        INNER JOIN Users u2 ON u2.User_Id = v.Visited_Employee_Id
        INNER JOIN Metadata m ON m.Meta_Sub_Id = vd.Title_id
        INNER JOIN Metadata m4 ON m4.Meta_Sub_Id = v.Purpose_Of_Visit
        INNER JOIN Visitor_Entry_Log vl ON vl.Visitor_Entry_Code = v.Visitor_Entry_Code
        INNER JOIN Users u ON u.User_Id = vl.Created_By
        LEFT JOIN Users u1 ON u1.User_Id = vl.Modified_By
    WHERE
    date(vl.Checked_In) BETWEEN date(FromDate)
                           AND date(ToDate)
        -- vl.Checked_In BETWEEN STR_TO_DATE(FromDate, '%Y-%m-%dT%H:%i:%s') 
--                            AND STR_TO_DATE(ToDate, '%Y-%m-%dT%H:%i:%s')
    
    UNION ALL
    
    SELECT DISTINCT
        v.Plant_Id AS PlantId,
        v.Visitor_Type_Id AS VisitorTypeId,
        'Extended Pass' AS VisitorTypeName,
        CONCAT(m.Meta_Sub_Description, '. ', vd.First_Name, ' ', vd.Last_Name) AS VisitorName,
        v.Mobile_No AS MobileNo,
        v.Visited_Employee_Id AS VisitedEmployeeId,
        u2.User_Name AS VisitorEmpName,
        v.Purpose_Of_Visit AS PurposeOfVisit,
        m4.Meta_Sub_Description AS PurposeOfVisitName,
        v.Visitor_Image_Url AS VisitorImageUrl,
        v.Visitor_Entry_Code AS VisitorEntryCode,
        p.Plant_Name AS PlantName,
        IFNULL(DATE_FORMAT(v.Visitor_Entry_Date, '%Y-%m-%d %H:%i:%s'), '') AS VisitorEntryDate,
        IFNULL(DATE_FORMAT(vl.Checked_In, '%Y-%m-%d %H:%i:%s'), '-') AS CheckedIn,
        IFNULL(DATE_FORMAT(vl.Checked_out, '%Y-%m-%d %H:%i:%s'), '-') AS CheckedOut,
        CASE WHEN vl.Checked_out IS NULL THEN '-'
             ELSE CONCAT(TIMESTAMPDIFF(MINUTE, vl.Checked_In, vl.Checked_out), ' Minutes')
        END AS StayTime,
        u.User_Name AS CheckedInBy,
        IFNULL(u1.User_Name, '-') AS CheckedOutBy,
        (SELECT GROUP_CONCAT(DISTINCT m.Area_Name SEPARATOR ', ') 
         FROM Visitor_Entry_Atv_Detail b 
         INNER JOIN Area m ON m.Area_Id = b.Area_To_Visit 
         WHERE b.Visitor_Entry_Id = v.Visitor_Entry_Id) AS AreatoVisitName
    FROM 
        Visitor_Entry_Detail vd
        INNER JOIN Visitor_Entry v ON v.Visitor_Entry_Id = vd.Visitor_Entry_Id AND v.Visitor_Type_Id = 36
        INNER JOIN Plant p ON p.Plant_Id = v.Plant_Id
        LEFT JOIN Users u2 ON u2.User_Id = v.Visited_Employee_Id
        LEFT JOIN Metadata m ON m.Meta_Sub_Id = vd.Title_id
        INNER JOIN Metadata m4 ON m4.Meta_Sub_Id = v.Purpose_Of_Visit
        LEFT JOIN Visitor_Entry_Log vl ON vl.Visitor_Entry_Code = v.Visitor_Entry_Code AND vl.Visitor_Entry_Detail_Id = vd.Visitor_Entry_Detail_Id
        LEFT JOIN Users u ON u.User_Id = vl.Created_By
        LEFT JOIN Users u1 ON u1.User_Id = vl.Modified_By
    WHERE 
		vl.Checked_In IS NULL OR
        date(vl.Checked_In) BETWEEN date(FromDate)
                           AND date(ToDate)
        -- vl.Checked_In BETWEEN STR_TO_DATE(FromDate, '%Y-%m-%dT%H:%i:%s') 
--                            AND STR_TO_DATE(ToDate, '%Y-%m-%dT%H:%i:%s')
    
    UNION ALL
    
    SELECT DISTINCT
        v.Plant_Id AS PlantId,
        v.Visitor_Type_Id AS VisitorTypeId,
        m.Meta_Sub_Description AS VisitorTypeName,
        v.Person_Name AS VisitorName,
        v.Mobile_No AS MobileNo,
        v.Visited_Employee_Id AS VisitedEmployeeId,
        u2.User_Name AS VisitorEmpName,
        v.Purpose_Of_Visit AS PurposeOfVisit,
        m4.Meta_Sub_Description AS PurposeOfVisitName,
        v.Visitor_Image_Url AS VisitorImageUrl,
        v.Visitor_Entry_Code AS VisitorEntryCode,
        p.Plant_Name AS PlantName,
        IFNULL(DATE_FORMAT(v.Visitor_Entry_Date, '%Y-%m-%d %H:%i:%s'), '') AS VisitorEntryDate,
        IFNULL(DATE_FORMAT(v.Entry_Time, '%Y-%m-%d %H:%i:%s'), '') AS CheckedIn,
        IFNULL(DATE_FORMAT(v.Exit_Time, '%Y-%m-%d %H:%i:%s'), '') AS CheckedOut,
        CASE WHEN v.Exit_Time IS NULL THEN ''
             ELSE CONCAT(TIMESTAMPDIFF(MINUTE, v.Entry_Time, v.Exit_Time), ' Minutes')
        END AS StayTime,
        u.User_Name AS CheckedInBy,
        '' AS CheckedOutBy,
        (SELECT GROUP_CONCAT(DISTINCT m.Area_Name SEPARATOR ', ') 
         FROM Visitor_Entry_Atv_Detail b 
         INNER JOIN Area m ON m.Area_Id = b.Area_To_Visit 
         WHERE b.Visitor_Entry_Id = v.Visitor_Entry_Id) AS AreatoVisitName
    FROM 
        Visitor_Entry v
        INNER JOIN Metadata m ON m.Meta_Sub_Id = v.Visitor_Type_Id
        INNER JOIN Plant p ON p.Plant_Id = v.Plant_Id
        left JOIN Users u2 ON u2.User_Id = v.Visited_Employee_Id
        left JOIN Users u ON u.User_Id = v.Created_By
        INNER JOIN Metadata m4 ON m4.Meta_Sub_Id = v.Purpose_Of_Visit
    WHERE 
        Visitor_Type_Id NOT IN (35, 36) AND 
	date(v.Created_On) BETWEEN date(FromDate)
                           AND date(ToDate)
        -- v.Created_On BETWEEN STR_TO_DATE(FromDate, '%Y-%m-%dT%H:%i:%s') 
--                           AND STR_TO_DATE(ToDate, '%Y-%m-%dT%H:%i:%s')
) AS A;

-- Select from the temporary table with conditions
SELECT * FROM TempSelect T
WHERE 
(PlantId IS NULL OR PlantId = '' OR FIND_IN_SET(T.PlantId, PlantId)) AND
    (VisitorTypeId IS NULL OR VisitorTypeId = '' OR FIND_IN_SET(T.VisitorTypeId, VisitorTypeId)) AND
    (PurposeOfVisit IS NULL OR PurposeOfVisit = '' OR FIND_IN_SET(T.PurposeOfVisit, PurposeOfVisit));

   
   END IF;
END//
DELIMITER ;
