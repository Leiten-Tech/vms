CREATE TABLE IF NOT EXISTS `Instructions` (
  `Instructions_Id` BIGINT AUTO_INCREMENT NOT NULL,
  `Company_Id` BIGINT NOT NULL,
  `Plant_Id` BIGINT NOT NULL,
  `Visitor_Type_Id` BIGINT NOT NULL,
  `Text_Input` VARCHAR(0)  NOT NULL,
  `Status` INT NULL DEFAULT NULL,
  PRIMARY KEY (`Instructions_Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_general_ci;
