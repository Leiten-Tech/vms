CREATE TABLE IF NOT EXISTS `Customer_Billing_Details` (
  `Customer_Billing_Detail_Id` BIGINT AUTO_INCREMENT NOT NULL,
  `Customer_Id` BIGINT NOT NULL,
  `Billing_Address1` VARCHAR(250) NULL DEFAULT NULL,
  `Billing_Address2` VARCHAR(250) NULL DEFAULT NULL,
  `City_Id` BIGINT NULL DEFAULT NULL,
  `State_Id` BIGINT NULL DEFAULT NULL,
  `Country_Id` BIGINT NULL DEFAULT NULL,
  `Pin_Code` INT NULL DEFAULT NULL,
  `Contact_Person` VARCHAR(50) NULL DEFAULT NULL,
  `Phone1` VARCHAR(50) NULL DEFAULT NULL,
  `Phone2` VARCHAR(50) NULL DEFAULT NULL,
  `Mobile_No` VARCHAR(50) NULL DEFAULT NULL,
  `Mail_Id` VARCHAR(50) NULL DEFAULT NULL,
  `Company_Id` BIGINT NOT NULL,
  `Plant_Id` BIGINT NOT NULL,
  PRIMARY KEY (`Customer_Billing_Detail_Id`),
  INDEX `fk_Customer_Customer_Id` (`Customer_Id` ASC) VISIBLE,
  CONSTRAINT `fk_Customer_Customer_Id`
    FOREIGN KEY (`Customer_Id`)
    REFERENCES `Customer` (`Customer_Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_general_ci;