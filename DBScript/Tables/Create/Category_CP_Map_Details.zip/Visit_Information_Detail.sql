CREATE TABLE IF NOT EXISTS `Visit_Information_Detail` (
  `Company_Id` BIGINT NULL DEFAULT NULL,
  `Plant_Id` BIGINT NULL DEFAULT NULL,
  `Gate_Id` BIGINT NULL DEFAULT NULL,
  `Visitor_Detail_Id` BIGINT NOT NULL AUTO_INCREMENT,
  `Visit_Id` BIGINT NOT NULL,
  `First_Name` VARCHAR(255) NOT NULL,
  `Last_Name` VARCHAR(255) NOT NULL,
  `Department_Id` BIGINT NULL DEFAULT NULL,
  `Dob` DATETIME(6) NULL DEFAULT NULL,
  `Mail_Id` VARCHAR(255) NOT NULL,
  `Mobile_No` VARCHAR(255) NOT NULL,
  `Address` VARCHAR(255) NOT NULL,
  `Document_Name` LONGTEXT NOT NULL,
  `Expiry_Date` DATETIME(6) NULL DEFAULT NULL,
  `WorkSeverity` INT NULL DEFAULT NULL,
  `Status` INT NOT NULL,
  PRIMARY KEY (`Visitor_Detail_Id`),
  CONSTRAINT `fk_Visit_Information_Detail_Visit_Id`
    FOREIGN KEY (`Visitor_Detail_Id`)
    REFERENCES `Visit_Information` (`Visit_Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_general_ci;