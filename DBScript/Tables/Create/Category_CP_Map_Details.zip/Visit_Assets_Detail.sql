CREATE TABLE IF NOT EXISTS `Visit_Assets_Detail` (
  `Asset_Id` BIGINT NOT NULL AUTO_INCREMENT,
  `Visitor_Detail_Id` BIGINT NOT NULL,
  `Asset_Name` VARCHAR(255) NOT NULL,
  `Asset_No` VARCHAR(255) NOT NULL,
  `Asset_Qty` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`Asset_Id`),
  INDEX `fk_Visit_Assets_Detail_Visit_Id` (`Visitor_Detail_Id` ASC) VISIBLE,
  CONSTRAINT `fk_Visit_Assets_Detail_Visit_Id`
    FOREIGN KEY (`Visitor_Detail_Id`)
    REFERENCES `Visit_Information_Detail` (`Visitor_Detail_Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_general_ci;