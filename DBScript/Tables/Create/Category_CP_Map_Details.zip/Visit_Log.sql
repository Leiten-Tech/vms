CREATE TABLE IF NOT EXISTS `Visit_Log` (
  `Company_Id` BIGINT NULL DEFAULT NULL,
  `Plant_Id` BIGINT NULL DEFAULT NULL,
  `Gate_Id` BIGINT NULL DEFAULT NULL,
  `Visit_Log_Id` BIGINT NOT NULL AUTO_INCREMENT,
  `Visitor_Detail_Id` BIGINT NOT NULL,
  `Visit_Code` LONGTEXT NOT NULL,
  `Checked_In` DATETIME(6) NOT NULL,
  `Checked_Out` DATETIME(6) NULL DEFAULT NULL,
  `Created_By` INT NOT NULL,
  `Created_On` DATETIME(6) NOT NULL,
  `Modified_By` INT NULL DEFAULT NULL,
  `Modified_On` DATETIME(6) NULL DEFAULT NULL,
  PRIMARY KEY (`Visit_Log_Id`),
  INDEX `fk_Visit_Information_Detail_Visitor_Detail_Id` (`Visitor_Detail_Id` ASC) VISIBLE,
  CONSTRAINT `fk_Visit_Information_Detail_Visitor_Detail_Id`
    FOREIGN KEY (`Visitor_Detail_Id`)
    REFERENCES `Visit_Information_Detail` (`Visitor_Detail_Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_general_ci;
